﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioConexiónLogin.CapaEntidades
{
  public  class Usuarios
    {

        public string nombre { get; set; }
        public string contra { get; set; }


    }
}
