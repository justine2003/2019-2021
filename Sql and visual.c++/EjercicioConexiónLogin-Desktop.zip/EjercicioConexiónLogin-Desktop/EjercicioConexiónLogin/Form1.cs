﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Reflection;
using System.Configuration;

namespace EjercicioConexiónLogin
{
    public partial class Form1 : Form 
    {
        SqlConnection conexion { get; set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            Login();
        }

        //Inicio y construcción del método Login
        public void Login() {

            //Inicio e implementación del validador y control de errores TRY-CATCH
            try
            {

                //Inicio de la declaración de la conección a la base de datos (Utilizar los using: "using System.Data.SqlClient;" y "using System.Configuration;")
                //El using System.Configuration; se debe agregar a nivel de las referencias del proyecto "REFERENCES", dando click derecho ADD - luego buscamos
                //System.configuration y lo añadimos al proyecto para que se reconozca al "ConfigurationManager"
                string cnn = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

                //Dentro de la siguiente estructura de control using ( conexion = new SqlConnection(cnn)){ }, se establece el código de interacción con la BD.
                using ( conexion = new SqlConnection(cnn))
                {

                    //Se abre la conección
                    conexion.Open();

                    //Se establece el SqlCommand para hacer la consulta a la DB desde acá.
                    //Se establece dentro de la consulta el controlador TextBox para comparar con lo que trae dentro a la otra de consultar por nombre de Uuuario
                    SqlCommand comando = new SqlCommand("SELECT [idUsuario] ,[contra] FROM [LIBRODB].[dbo].[Usuario] where idUsuario='" + txtUsuario.Text + "'");


                    //Tambien se puede realizar con procedimientos almacenados.
                    //comando.CommandType = CommandType.StoredProcedure;
                    //comando.Parameters.AddWithValue("@usuario", txtUsuario.Text);

                    //DataSet construye una tabla dinámica en memoria para guardar la lista que se consulta de la base de datos.
                    DataSet ds = ExecuteReader(comando, "Usuario");

                    //Creación de variable de tipo OBJETO, en este casoo de Usuarios para guardar la colección de datos de la clase Usuario en la CapaEntidades
                    CapaEntidades.Usuarios u = new CapaEntidades.Usuarios();

                    //Recorrido de los elementos dentro del DataSet para sacar los elementos que escojamos dentro.
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        //Se le guarda directamente a la variable de la Clase Usuarios el elemento que viene de la base de datos, por ello especificamos estrictamente
                        //el nombre de la columna establecido en la BD que se va a guarda en la variable correspondiente de la clase dentro del row[""].toString();
                        u.nombre = row["idUsuario"].ToString();
                        u.contra = row["contra"].ToString();
                    }

                    //Validación para comparar lo que viene en el controlador TEXTBOX y lo que esta guardado en la base de datos.

                    if (u.nombre == txtUsuario.Text && u.contra == txtContra.Text)
                    {
                        MessageBox.Show("Si salio", "Yeah", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        frmPrincipal frm = new frmPrincipal();
                        frm.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("No salio", "No", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }                  

                }  
            }

            //Control de errores establecido en el catch para una descripción completa del error.
            catch (Exception er)
            {

                StringBuilder msg = new StringBuilder();
                msg.AppendFormat("Message        {0}\n", er.Message);
                msg.AppendFormat("Source         {0}\n", er.Source);
                msg.AppendFormat("InnerException {0}\n", er.InnerException);
                msg.AppendFormat("StackTrace     {0}\n", er.StackTrace);
                msg.AppendFormat("TargetSite     {0}\n", er.TargetSite);

                MessageBox.Show(msg.ToString(), "Yeah", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }







        }


        //Método que construye en la tabla dinámica temporal del DataSet con los elementos que vienen del select.
        public DataSet ExecuteReader(SqlCommand sqlCommand, String tabla)
        {

            DataSet dsTabla = new DataSet();
            try
            {
                using (SqlDataAdapter adaptador = new SqlDataAdapter(sqlCommand))
                {
                    sqlCommand.Connection = conexion;
                    dsTabla = new DataSet();
                    adaptador.Fill(dsTabla, tabla);
                }
                return dsTabla;
            }
            catch (Exception ex)
            {
                ex.Source += " SQL: " + sqlCommand.CommandText.ToString();
                //Log.Write(MethodBase.GetCurrentMethod().Name, ex);
                throw ex;
            }
            finally
            {

                if (dsTabla != null)
                    dsTabla.Dispose();


            }



        }
    }
}
