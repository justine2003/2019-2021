﻿
namespace EjercicioConexiónLogin
{
    partial class ManteAutores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.IDAutor = new System.Windows.Forms.TextBox();
            this.NombreAutor = new System.Windows.Forms.TextBox();
            this.Estado = new System.Windows.Forms.ComboBox();
            this.Insertar = new System.Windows.Forms.Button();
            this.Actualisar = new System.Windows.Forms.Button();
            this.Eliminar = new System.Windows.Forms.Button();
            this.Limpiar = new System.Windows.Forms.Button();
            this.Cancelar = new System.Windows.Forms.Button();
            this.ConsultarAutor = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID Autor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 283);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Estado";
            // 
            // IDAutor
            // 
            this.IDAutor.Location = new System.Drawing.Point(36, 79);
            this.IDAutor.Multiline = true;
            this.IDAutor.Name = "IDAutor";
            this.IDAutor.Size = new System.Drawing.Size(122, 31);
            this.IDAutor.TabIndex = 3;
            // 
            // NombreAutor
            // 
            this.NombreAutor.Location = new System.Drawing.Point(36, 175);
            this.NombreAutor.Multiline = true;
            this.NombreAutor.Name = "NombreAutor";
            this.NombreAutor.Size = new System.Drawing.Size(166, 60);
            this.NombreAutor.TabIndex = 4;
            // 
            // Estado
            // 
            this.Estado.FormattingEnabled = true;
            this.Estado.Items.AddRange(new object[] {
            "Activo",
            "Inactivo"});
            this.Estado.Location = new System.Drawing.Point(36, 299);
            this.Estado.Name = "Estado";
            this.Estado.Size = new System.Drawing.Size(121, 21);
            this.Estado.TabIndex = 5;
            // 
            // Insertar
            // 
            this.Insertar.Location = new System.Drawing.Point(36, 356);
            this.Insertar.Name = "Insertar";
            this.Insertar.Size = new System.Drawing.Size(111, 40);
            this.Insertar.TabIndex = 6;
            this.Insertar.Text = "Insertar";
            this.Insertar.UseVisualStyleBackColor = true;
            this.Insertar.Click += new System.EventHandler(this.Insertar_Click);
            // 
            // Actualisar
            // 
            this.Actualisar.Location = new System.Drawing.Point(153, 356);
            this.Actualisar.Name = "Actualisar";
            this.Actualisar.Size = new System.Drawing.Size(111, 40);
            this.Actualisar.TabIndex = 7;
            this.Actualisar.Text = "Actualisar";
            this.Actualisar.UseVisualStyleBackColor = true;
            // 
            // Eliminar
            // 
            this.Eliminar.Location = new System.Drawing.Point(270, 356);
            this.Eliminar.Name = "Eliminar";
            this.Eliminar.Size = new System.Drawing.Size(111, 40);
            this.Eliminar.TabIndex = 8;
            this.Eliminar.Text = "Eliminar";
            this.Eliminar.UseVisualStyleBackColor = true;
            // 
            // Limpiar
            // 
            this.Limpiar.Location = new System.Drawing.Point(387, 356);
            this.Limpiar.Name = "Limpiar";
            this.Limpiar.Size = new System.Drawing.Size(111, 40);
            this.Limpiar.TabIndex = 9;
            this.Limpiar.Text = "Limpiar";
            this.Limpiar.UseVisualStyleBackColor = true;
            // 
            // Cancelar
            // 
            this.Cancelar.Location = new System.Drawing.Point(504, 356);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(111, 40);
            this.Cancelar.TabIndex = 10;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            // 
            // ConsultarAutor
            // 
            this.ConsultarAutor.Location = new System.Drawing.Point(462, 49);
            this.ConsultarAutor.Name = "ConsultarAutor";
            this.ConsultarAutor.Size = new System.Drawing.Size(111, 40);
            this.ConsultarAutor.TabIndex = 11;
            this.ConsultarAutor.Text = "Consultar";
            this.ConsultarAutor.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(465, 122);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(318, 177);
            this.dataGridView1.TabIndex = 12;
            // 
            // ManteAutores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.ConsultarAutor);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.Limpiar);
            this.Controls.Add(this.Eliminar);
            this.Controls.Add(this.Actualisar);
            this.Controls.Add(this.Insertar);
            this.Controls.Add(this.Estado);
            this.Controls.Add(this.NombreAutor);
            this.Controls.Add(this.IDAutor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ManteAutores";
            this.Text = "ManteAutores";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox IDAutor;
        private System.Windows.Forms.TextBox NombreAutor;
        private System.Windows.Forms.ComboBox Estado;
        private System.Windows.Forms.Button Insertar;
        private System.Windows.Forms.Button Actualisar;
        private System.Windows.Forms.Button Eliminar;
        private System.Windows.Forms.Button Limpiar;
        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button ConsultarAutor;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}