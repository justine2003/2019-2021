﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioConexiónLogin
{
    public partial class ManteAutores : Form
    {
        SqlConnection conexion { get; set; }

        public ManteAutores()
        {
            InitializeComponent();
        }

        public void InsertarAutor()
        {
            try
            {
                string cnn = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

                using (conexion = new SqlConnection(cnn))
                {
                    conexion.Open();

                    SqlCommand comando = new SqlCommand("PA_InsertarUsuarios");

                    if (IDAutor.Text == "")
                    {
                        MessageBox.Show("Debe ingresar el ID y que no sea repetido", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        comando.CommandType = CommandType.StoredProcedure;
                        comando.Parameters.AddWithValue("@idAutor", IDAutor.Text);
                        comando.Parameters.AddWithValue("@nombre", NombreAutor.Text);
                        comando.Parameters.AddWithValue("@estado", Estado.SelectedItem);

                        ExecuteNonQuery(comando);

                        MessageBox.Show("Registro exitoso", "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }
            }
            catch (Exception er)
            {
                StringBuilder msg = new StringBuilder();
                msg.AppendFormat("Messague  {0}\n",er.Message);
                msg.AppendFormat("Messague  {0}\n", er.Source);
                msg.AppendFormat("Messague  {0}\n", er.InnerException);
                msg.AppendFormat("Messague  {0}\n", er.StackTrace);
                msg.AppendFormat("Messague  {0}\n", er.TargetSite);
                MessageBox.Show(msg.ToString(),"ERROR",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        public int ExecuteNonQuery(SqlCommand sqlCommand)
        {

            int registrosafectados = 0;
            try
            {

                sqlCommand.Connection = conexion;

                registrosafectados = sqlCommand.ExecuteNonQuery();

                return registrosafectados;

            }
            catch (Exception er)
            {

                StringBuilder msg = new StringBuilder();
                msg.AppendFormat("Message {0}\n", er.Message);
                msg.AppendFormat("Source {0}\n", er.Source);
                msg.AppendFormat("InnerException {0}\n", er.InnerException);
                msg.AppendFormat("StackTrace {0}\n", er.StackTrace);
                msg.AppendFormat("TargetSite {0}\n", er.TargetSite);

                //Response.Write("<script>alert('" + msg + "')</script>");
                MessageBox.Show(msg.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }
        }


        private void Insertar_Click(object sender, EventArgs e)
        {
            InsertarAutor();
        }
    }
}
