﻿namespace EjercicioConexiónLogin
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Autor = new System.Windows.Forms.Button();
            this.Temas = new System.Windows.Forms.Button();
            this.Libros = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Autor
            // 
            this.Autor.BackColor = System.Drawing.Color.Lime;
            this.Autor.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.Autor.Location = new System.Drawing.Point(129, 118);
            this.Autor.Name = "Autor";
            this.Autor.Size = new System.Drawing.Size(61, 31);
            this.Autor.TabIndex = 0;
            this.Autor.Text = "Autor";
            this.Autor.UseVisualStyleBackColor = false;
            this.Autor.Click += new System.EventHandler(this.Autor_Click);
            // 
            // Temas
            // 
            this.Temas.BackColor = System.Drawing.Color.Lime;
            this.Temas.Location = new System.Drawing.Point(129, 193);
            this.Temas.Name = "Temas";
            this.Temas.Size = new System.Drawing.Size(61, 31);
            this.Temas.TabIndex = 1;
            this.Temas.Text = "Temas";
            this.Temas.UseVisualStyleBackColor = false;
            this.Temas.Click += new System.EventHandler(this.Temas_Click);
            // 
            // Libros
            // 
            this.Libros.BackColor = System.Drawing.Color.Lime;
            this.Libros.Location = new System.Drawing.Point(129, 272);
            this.Libros.Name = "Libros";
            this.Libros.Size = new System.Drawing.Size(61, 31);
            this.Libros.TabIndex = 2;
            this.Libros.Text = "Libros";
            this.Libros.UseVisualStyleBackColor = false;
            this.Libros.Click += new System.EventHandler(this.Libros_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(33, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 31);
            this.label1.TabIndex = 3;
            this.label1.Text = "Menu Mantenimiento";
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(360, 355);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Libros);
            this.Controls.Add(this.Temas);
            this.Controls.Add(this.Autor);
            this.Name = "frmPrincipal";
            this.Text = "frmPrincipal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Autor;
        private System.Windows.Forms.Button Temas;
        private System.Windows.Forms.Button Libros;
        private System.Windows.Forms.Label label1;
    }
}