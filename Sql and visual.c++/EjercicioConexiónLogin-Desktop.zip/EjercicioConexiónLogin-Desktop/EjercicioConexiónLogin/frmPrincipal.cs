﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioConexiónLogin
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void Autor_Click(object sender, EventArgs e)
        {
            ManteAutores autor = new ManteAutores();
            autor.Show();
        }

        private void Temas_Click(object sender, EventArgs e)
        {
            ManteTemas tema = new ManteTemas();
            tema.Show();
        }

        private void Libros_Click(object sender, EventArgs e)
        {
            ManteLibro libro = new ManteLibro();
            libro.Show();
        }
    }
}
