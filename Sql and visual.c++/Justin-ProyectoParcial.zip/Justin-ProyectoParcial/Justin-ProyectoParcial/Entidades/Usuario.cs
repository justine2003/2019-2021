﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Justin_ProyectoParcial.Entidades
{
    public class Usuario
    {
        public string NombreUsuario { get; set; }
        public string NumCedula { get; set; }
    }
}