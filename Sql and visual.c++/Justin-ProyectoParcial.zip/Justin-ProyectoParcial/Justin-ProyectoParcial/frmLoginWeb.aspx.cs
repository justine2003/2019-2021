﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Justin_ProyectoParcial
{
    public partial class frmLoginWeb : System.Web.UI.Page
    {
        SqlConnection conexion { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnIngresar_Click(object sender, EventArgs e)
        {
            try
            {
                String cnn = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

                using(conexion = new SqlConnection(cnn))
                {
                    conexion.Open();
                    SqlCommand comando = new SqlCommand("select NumCedula,NombreUsuario from Usuario where NombreUsuario='" + txtUsuario.Text + "'");
                    DataSet ds = ExecuteReader(comando, "Usuario");
                    Entidades.Usuario EU = new Entidades.Usuario();

                    foreach(DataRow row in ds.Tables[0].Rows)
                    {
                        EU.NombreUsuario = row["NombreUsuario"].ToString();
                        EU.NumCedula = row["NumCedula"].ToString();
                    }
                    if (EU.NombreUsuario == txtUsuario.Text && EU.NumCedula == txtCedula.Text)
                    {
                        Response.Redirect("frmWebProducto.aspx",false);
                    }
                    else
                    {
                        Response.Write("<script>alert('Usuario o contraseña incorrectos')</script>");
                    }
                }

            }
            catch (Exception er)
            {
                StringBuilder msg = new StringBuilder();
                msg.AppendFormat("Message        {0}\n", er.Message);
                msg.AppendFormat("Source         {0}\n", er.Source);
                msg.AppendFormat("InnerException {0}\n", er.InnerException);
                msg.AppendFormat("StackTrace     {0}\n", er.StackTrace);
                msg.AppendFormat("TargetSite     {0}\n", er.TargetSite);

                lblError.Text = msg.ToString();
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            txtUsuario.Text = "";
            txtCedula.Text = "";
        }


        public DataSet ExecuteReader(SqlCommand sqlCommand, String tabla)
        {

            DataSet dsTabla = new DataSet();
            try
            {
                using (SqlDataAdapter adaptador = new SqlDataAdapter(sqlCommand))
                {
                    sqlCommand.Connection = conexion;
                    dsTabla = new DataSet();
                    adaptador.Fill(dsTabla, tabla);
                }
                return dsTabla;
            }
            catch (Exception ex)
            {
                ex.Source += " SQL: " + sqlCommand.CommandText.ToString();
                //Log.Write(MethodBase.GetCurrentMethod().Name, ex);
                throw ex;
            }
            finally
            {

                if (dsTabla != null)
                    dsTabla.Dispose();
            }

        }
    }
}