select * from Autor
select * from Tema