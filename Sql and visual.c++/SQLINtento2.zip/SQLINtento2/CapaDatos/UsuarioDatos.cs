﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
        public class UsuarioDatos
        {
        
        public static DataSet SeleccionarUsuarioXID(string idUsuario)
            {
                Database db = DatabaseFactory.CreateDatabase("Default");

                SqlCommand comando = new SqlCommand("PA_SeleccionarUsuarioXID");

                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@idUsuario",idUsuario);

                DataSet ds = db.ExecuteReader(comando, "Usuario");
                return ds;

            }

        }
}
