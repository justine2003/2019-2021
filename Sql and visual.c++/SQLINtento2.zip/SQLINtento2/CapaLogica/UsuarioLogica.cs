﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidades;
using CapaDatos;
using System.Data;

namespace CapaLogica
{
   public class UsuarioLogica
    {
        public Usuariocs SeleccionarUsuarioXID(string idUsuario)
        {
            Usuariocs usu = new Usuariocs();

            DataSet ds = UsuarioDatos.SeleccionarUsuarioXID(idUsuario);

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                usu.idUsuario = row["idUsuario"].ToString();
                usu.contra = row["contra"].ToString();
            }

            return usu;

        }
    }
}
