﻿
namespace SQLINtento2
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancelar = new System.Windows.Forms.Button();
            this.Accerptar = new System.Windows.Forms.Button();
            this.usuario = new System.Windows.Forms.TextBox();
            this.contraseña2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Cancelar
            // 
            this.Cancelar.Location = new System.Drawing.Point(157, 185);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(75, 23);
            this.Cancelar.TabIndex = 0;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            this.Cancelar.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // Accerptar
            // 
            this.Accerptar.Location = new System.Drawing.Point(42, 185);
            this.Accerptar.Name = "Accerptar";
            this.Accerptar.Size = new System.Drawing.Size(75, 23);
            this.Accerptar.TabIndex = 1;
            this.Accerptar.Text = "Acceptar";
            this.Accerptar.UseVisualStyleBackColor = true;
            this.Accerptar.Click += new System.EventHandler(this.Accerptar_Click);
            // 
            // usuario
            // 
            this.usuario.Location = new System.Drawing.Point(42, 46);
            this.usuario.Name = "usuario";
            this.usuario.Size = new System.Drawing.Size(190, 20);
            this.usuario.TabIndex = 2;
            this.usuario.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // contraseña2
            // 
            this.contraseña2.Location = new System.Drawing.Point(42, 123);
            this.contraseña2.Name = "contraseña2";
            this.contraseña2.Size = new System.Drawing.Size(190, 20);
            this.contraseña2.TabIndex = 3;
            this.contraseña2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Usuario";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Contraseña";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(273, 247);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.contraseña2);
            this.Controls.Add(this.usuario);
            this.Controls.Add(this.Accerptar);
            this.Controls.Add(this.Cancelar);
            this.Name = "Login";
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button Accerptar;
        private System.Windows.Forms.TextBox usuario;
        private System.Windows.Forms.TextBox contraseña2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}