﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaDatos;
using CapaEntidades;
using CapaLogica;

namespace SQLINtento2
{
    public partial class Login : Form
    {
        private UsuarioLogica logica = new UsuarioLogica();

        public Login()
        {
            InitializeComponent();
        }

        private void Accerptar_Click(object sender, EventArgs e)
        {
            try
            {
                Usuariocs usu = logica.SeleccionarUsuarioXID(usuario.Text);

                string cedula = usuario.Text;
                string contra = contraseña2.Text;

                if (usu.idUsuario == usuario.Text && usu.contra == contraseña2.Text)
                {
                    FrmPrincipal frm = new FrmPrincipal();
                    frm.Show();
                }

            }
            catch (Exception er)
            {
                StringBuilder msg = new StringBuilder();
                msg.AppendFormat("Message        {0}\n", er.Message);
                msg.AppendFormat("Source         {0}\n", er.Source);
                msg.AppendFormat("InnerException {0}\n", er.InnerException);
                msg.AppendFormat("StackTrace     {0}\n", er.StackTrace);
                msg.AppendFormat("TargetSite     {0}\n", er.TargetSite);
          
                MessageBox.Show(msg.ToString(), "ERROR" ,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            usuario.Text = "";
            contraseña2.Text = "";
        }
    }
}
