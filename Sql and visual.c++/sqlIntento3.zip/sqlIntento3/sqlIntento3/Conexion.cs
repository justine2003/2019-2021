﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace sqlIntento3
{
    class Conexion
    {
     public static SqlConnection Conectar()
        {
            SqlConnection cn = new SqlConnection("SERVER=LAPTOP_HP\\MSSQLSERVERJ20;DATABASE=LIBRODB;Integrated security=true");
            cn.Open();

            return cn;
        }
    }
}
