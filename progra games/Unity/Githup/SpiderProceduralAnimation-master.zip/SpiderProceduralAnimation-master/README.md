# SpiderProceduralAnimation

## Setup
- Unzip or clone the repository in the Assets folder of an unity project. It has been created on unity 2019.4.14f1 with URP but other than the materials, it should work on any RP.
- Make sure to have the animation rigging package installed. You can install it via package manager (be careful it is still a preview package)

## Explaination video
https://www.youtube.com/watch?v=AhywDyu0EGw
